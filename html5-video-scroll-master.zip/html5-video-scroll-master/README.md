# HTML5 Scroll Based Video Tutorial Project

This is the project based on the following tutorial:
[Create an Awesome Scroll-based HTML5 Video Explainer](https://youtu.be/HiegEfkenXA)

## More Awesome Content

Do me a big ol' favor and check out these awesome links. I release new video tutorials on full stack development Monday-Thursday @ 10:30 AM ET!

* Subscribe to the [DesignCourse YouTube Channel](http://youtube.com/designcourse)
* Check out the associated website [Coursetro Full Stack Development Training](https://coursetro.com)
* [Twitter](https://twitter.com/designcoursecom)
* [Facebook](https://facebook.com/coursetro)

Enjoy!